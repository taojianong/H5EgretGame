declare module Zlib {
    class RawInflate {
    	constructor(input: any, opt_params?: any);
    	decompress():any;
    }
}